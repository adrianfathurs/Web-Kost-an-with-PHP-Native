<?php
include "koneksi.php";
?>
<!DOCTYPE html>
<html>
<head>
	<title>eroorr</title>
</head>
<body>
cddssd
</body>
</html>