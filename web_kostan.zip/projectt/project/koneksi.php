<?php
$dbservername="localhost";
$dbusername="root";
$dbpassword="";
$dbdatabase="kostaja";

$konek=mysqli_connect($dbservername,$dbusername,$dbpassword,$dbdatabase);


?>