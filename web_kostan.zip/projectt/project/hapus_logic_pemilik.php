<?php
include "koneksi.php";
$id_kost=$_GET['id'];
echo $id_kost;

$query=mysqli_query($konek,"Delete from kost where id_kost='$id_kost'");
?>